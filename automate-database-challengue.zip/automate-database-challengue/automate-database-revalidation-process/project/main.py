import pandas as pd
import json
from database import DatabaseInfo, Session
import smtplib
from email.mime.text import MIMEText
from dotenv import load_dotenv
import os
from colorama import init, Fore, Style

# Inicializa colorama
init(autoreset=True)

# Carga las variables de entorno desde el archivo .env
load_dotenv()

SMTP_HOST = os.getenv('SMTP_HOST')
SMTP_PORT = os.getenv('SMTP_PORT')
EMAIL_USER = os.getenv('SMTP_EMAIL_USER')
EMAIL_PASSWORD = os.getenv('SMTP_EMAIL_PASSWORD')
DEFAULT_MANAGER_EMAIL = os.getenv('DEFAULT_MANAGER_EMAIL')

# Verifica que todas las variables de entorno estén cargadas correctamente
if not SMTP_HOST or not SMTP_PORT or not EMAIL_USER or not EMAIL_PASSWORD or not DEFAULT_MANAGER_EMAIL:
    raise EnvironmentError(f"{Fore.RED}One or more environment variables are missing. Please check your .env file.")

SMTP_PORT = int(SMTP_PORT)

def read_json(file_path):
    print(f"{Fore.BLUE}Reading JSON file from {file_path}")
    with open(file_path) as f:
        data = json.load(f)
    print(f"{Fore.BLUE}Loaded {len(data)} records from JSON")
    return data

def read_csv(file_path):
    print(f"{Fore.BLUE}Reading CSV file from {file_path}")
    data = pd.read_csv(file_path)
    print(f"{Fore.BLUE}Loaded {len(data)} records from CSV")
    return data

def insert_data(json_data, csv_data, session):
    print(f"{Fore.GREEN}Inserting data into the database")
    high_classified_entries = []
    for entry in json_data:
        # Validación y manejo de campos incompletos
        owner_email = entry.get('owner_email')
        classification = entry.get('classification')
        database_name = entry.get('database_name', 'Unknown Database')

        if not owner_email or not classification:
            print(f"{Fore.YELLOW}Incomplete entry detected, using default values: {entry}")
            if not owner_email:
                owner_email = 'unknown@example.com'  # Valor por defecto
            if not classification:
                classification = 'unknown'  # Valor por defecto

        manager_email_row = csv_data[csv_data['user_id'] == owner_email]
        if not manager_email_row.empty:
            manager_email = manager_email_row['user_manager'].values[0]
        else:
            manager_email = DEFAULT_MANAGER_EMAIL
            print(f"{Fore.YELLOW}Manager not found for owner_email: {owner_email}. Using default manager email: {DEFAULT_MANAGER_EMAIL}")

        new_entry = DatabaseInfo(
            database_name=database_name,
            owner_email=owner_email,
            manager_email=manager_email,
            classification=classification
        )
        session.add(new_entry)
        print(f"{Fore.GREEN}Inserted record for {database_name}")

        if classification == 'high':
            high_classified_entries.append((manager_email, owner_email, database_name))
    
    session.commit()
    print(f"{Fore.GREEN}Data insertion complete")
    return high_classified_entries

def send_email(manager_email, owner_email, database_name):
    print(f"{Fore.CYAN}Sending email to {manager_email} for database {database_name}")
    msg = MIMEText(f"Please confirm the classification of the database {database_name} owned by {owner_email}.")
    msg['Subject'] = 'Database Classification Confirmation'
    msg['From'] = EMAIL_USER
    msg['To'] = manager_email

    try:
        # Configura el servidor SMTP
        with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT) as server:
            server.login(EMAIL_USER, EMAIL_PASSWORD)
            server.sendmail(msg['From'], [msg['To']], msg.as_string())
        print(f"{Fore.CYAN}Email sent to {manager_email}")
    except smtplib.SMTPAuthenticationError as e:
        print(f"{Fore.RED}SMTP Authentication Error: {e}")
    except Exception as e:
        print(f"{Fore.RED}Error: {e}")

def notify_managers(entries):
    print(f"{Fore.MAGENTA}Notifying managers")
    for manager_email, owner_email, database_name in entries:
        send_email(manager_email, owner_email, database_name)
    print(f"{Fore.MAGENTA}All notifications sent")

if __name__ == "__main__":
    try:
        json_data = read_json('project/data.json')
        csv_data = read_csv('project/users.csv')
        session = Session()
        high_classified_entries = insert_data(json_data, csv_data, session)
        notify_managers(high_classified_entries)
    except Exception as e:
        print(f"{Fore.RED}Error: {e}")

# Automated Database Revalidation Process

Este proyecto automatiza el proceso de revalidación de bases de datos, guardando la información en una base de datos y enviando correos electrónicos a los managers para las bases de datos clasificadas como "high".

## Requisitos

1. **Python 3.8+**
2. **pip** (gestor de paquetes de Python)
3. **Virtualenv** (opcional pero recomendado)

## Instalación

### 1. Clona el Repositorio

```bash
git clone <URL_DEL_REPOSITORIO>
cd <NOMBRE_DEL_DIRECTORIO_DEL_PROYECTO>
```

### 2. Crea y activa un entorno virtual

```bash
python -m venv env
source env/bin/activate   # En Windows usa `.\env\Scripts\activate`
```

### 3. Instala las dependencias

```bash
pip install -r project/requirements.txt
```

## Configuración

### 1. Archivo `.env`

Crea un archivo `.env` en el directorio raíz del proyecto (``project_root``) con el siguiente contenido:

```env
SMTP_HOST=smtp.hostinger.com
SMTP_PORT=465
SMTP_EMAIL_USER=security-test@desarrollo-api.lat
SMTP_EMAIL_PASSWORD=-aJ182g*cw7
DEFAULT_MANAGER_EMAIL=manager+default@desarrollo-api.lat
```

### 2. Archivos de datos

Asegúrate de que los archivos `data.json` y `users.csv` estén en el directorio `project`:

- data.json

```json
[
    {
        "database_name": "DB1",
        "owner_email": "user+test1@desarrollo-api.lat",
        "classification": "high"
    },
    {
        "database_name": "DB2",
        "owner_email": "user+test2@desarrollo-api.lat",
        "classification": "medium"
    },
    {
        "database_name": "DB3",
        "owner_email": "user+test3@desarrollo-api.lat",
        "classification": "low"
    },
    {
        "database_name": "DB4",
        "owner_email": "user+test4@desarrollo-api.lat",
        "classification": "high"
    },
    {
        "database_name": "DB5",
        "owner_email": "user+test5@desarrollo-api.lat"
    },
    {
        "database_name": "DB6"
    },
    {
        "database_name": "DB7",
        "owner_email": "user+test7@desarrollo-api.lat",
        "classification": "medium"
    },
    {   
        "database_name": "DB8",
        "owner_email": "user+test8@desarrollo-api.lat"
    },
    {
        "database_name": "DB9",
        "classification": "low"
    },
    {
        "database_name": "DB10",
        "owner_email": "user+test10@desarrollo-api.lat",
        "classification": "high"
    }
]
```

- user.csv

```csv
row_id,user_id,user_state,user_manager
1,user+test1@desarrollo-api.lat,active,manager+test1@desarrollo-api.lat
2,user+test2@desarrollo-api.lat,active,manager+test2@desarrollo-api.lat
3,user+test3@desarrollo-api.lat,active,manager+test3@desarrollo-api.lat
4,user+test4@desarrollo-api.lat,active,manager+test4@desarrollo-api.lat
5,user+test5@desarrollo-api.lat,active,manager+test5@desarrollo-api.lat
6,user+test6@desarrollo-api.lat,active,manager+test6@desarrollo-api.lat
7,user+test7@desarrollo-api.lat,active,manager+test7@desarrollo-api.lat
8,user+test8@desarrollo-api.lat,active,manager+test8@desarrollo-api.lat
9,user+test9@desarrollo-api.lat,active,manager+test9@desarrollo-api.lat
10,user+test10@desarrollo-api.lat,active,manager+test10@desarrollo-api.lat
```

## Ejecución

### 1. Activa el entorno virtual

Si aún no has activado el entorno virtual:

```bash
source env/bin/activate   # En Windows usa `.\env\Scripts\activate`
```

### 3. Ejecuta el Script Principal

```bash
python project/main.py   # En Windows usa `python .\project\main.py`
```

## Descripción de la aplicación

La aplicación procesa archivos JSON y CSV, guarda la información en una base de datos y envía correos electrónicos a los managers de las bases de datos clasificadas como "high".

### Supuestos y problemas

- Supuestos:
  - Se asume que los campos críticos pueden estar incompletos en el archivo JSON y se manejan usando valores predeterminados.
  - Se asume que los correos electrónicos de los managers se encuentran en el archivo CSV.

- Problemas y soluciones:
  - **Falta de Campos Críticos:** Si faltan `owner_email` o `classification`, se utilizan valores predeterminados y se registra la entrada incompleta.
  - **Manager No Encontrado:** Si no se encuentra el manager correspondiente, se utiliza un correo electrónico de manager predeterminado.

## Librería utilizadas

- **pandas:** Para manejar archivos CSV y JSON.
- **sqlalchemy:** Para manejar la base de datos.
- **smtplib:** Para enviar correos electrónicos.
- **python-dotenv:** Para manejar variables de entorno.
- **colorama:** Para colorear los logs en la terminal.

## Dockerización

### 1. Dockerfile

Crea un archivo llamado `Dockerfile` en el directorio raíz del proyecto (`project_root`) con el siguiente contenido:

```Dockerfile
# Usa una imagen base de Python
FROM python:3.8-slim

# Establece el directorio de trabajo en el contenedor
WORKDIR /app

# Copia el archivo de requisitos al contenedor
COPY project/requirements.txt requirements.txt

# Instala las dependencias
RUN pip install -r requirements.txt

# Copia el contenido del proyecto al contenedor
COPY project/ .

# Establece la variable de entorno para no almacenar el buffer
ENV PYTHONUNBUFFERED=1

# Comando por defecto para ejecutar el script principal
CMD ["python", "main.py"]
```

### 2. docker-compose.yml

Crea un archivo llamado `docker-compose.yml` en el directorio raíz del proyecto (`project_root`) con el siguiente contenido:

```yaml
services:
  app:
    build: .
    volumes:
      - ./project:/app
    env_file:
      - .env
```

### Instrucciones para Construir y Ejecutar el Contenedor Docker

Asegúrate de que el demonio de Docker esté corriendo. En la mayoría de los sistemas operativos, puedes iniciar Docker desde la aplicación Docker Desktop.

### 1. Ajustar rutas relativas en `main.py`

Para ejecutar el script correctamente usando Docker tendrás que modificar la linea 101 y 102 del archivo `main.py` para que encuente correctamente los archivos JSON y CSV.

Pasa de

```python
json_data = read_json('project/data.json')
csv_data = read_csv('project/users.csv')
```

A

```python
json_data = read_json('data.json')
csv_data = read_csv('users.csv')
```

#### 2. Construir la Imagen Docker

Desde el directorio raíz del proyecto (`project_root`), ejecuta el siguiente comando para construir la imagen Docker:

```bash
docker-compose build
```

#### 3. Ejecutar el Contenedor

Después de construir la imagen, ejecuta el siguiente comando para iniciar el contenedor:

```bash
docker-compose up
```

Esto levantará el contenedor y ejecutará la aplicación dentro del contenedor Docker.

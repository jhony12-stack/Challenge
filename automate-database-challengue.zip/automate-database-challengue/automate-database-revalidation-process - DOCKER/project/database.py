from sqlalchemy import create_engine, Column, String, Integer
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

Base = declarative_base()

class DatabaseInfo(Base):
    __tablename__ = 'database_info'
    id = Column(Integer, primary_key=True)
    database_name = Column(String)
    owner_email = Column(String)
    manager_email = Column(String)
    classification = Column(String)

engine = create_engine('sqlite:///databases.db')
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()
